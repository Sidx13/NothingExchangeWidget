package com.example.nothingexchange

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExchangeUpdateWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val connection = (URL(API_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 15000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "NothingExchangeWidget/1.0")
            }
            val body = try {
                if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
                connection.inputStream.bufferedReader().use { it.readText() }
            } finally {
                connection.disconnect()
            }

            val rates = JSONArray(body)
            var usd: Double? = null
            var eur: Double? = null
            for (i in 0 until rates.length()) {
                val item = rates.getJSONObject(i)
                when (item.optString("cc")) {
                    "USD" -> usd = item.optDouble("rate").takeIf { it > 0.0 }
                    "EUR" -> eur = item.optDouble("rate").takeIf { it > 0.0 }
                }
            }
            val usdRate = usd ?: return Result.retry()
            val eurRate = eur ?: return Result.retry()

            val prefs = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            prefs.edit()
                .putString("usd_uah", format(usdRate, 2))
                .putString("eur_uah", format(eurRate, 2))
                .putString("usd_eur", format(usdRate / eurRate, 4))
                .putString("updated", "NBU · ${SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date())}")
                .apply()

            ExchangeWidgetProvider.renderAll(applicationContext)
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private fun format(value: Double, decimals: Int): String =
        String.format(Locale.US, "%1$.${decimals}f", value)

    companion object {
        const val PREFS = "exchange_rates"
        private const val API_URL = "https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json"
    }
}
