package com.example.nothingexchange

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/** Draws the entire widget as a bitmap so every glyph uses the same circular dot matrix. */
object DotMatrixRenderer {
    private const val W = 1000
    private const val H = 600
    private const val BG = 0xFF101010.toInt()
    private const val WHITE = 0xFFF2F2F2.toInt()
    private const val MUTED = 0xFF858585.toInt()
    private const val DIM = 0xFF303030.toInt()
    private const val RED = 0xFFE52B32.toInt()

    private val glyphs = mapOf(
        'A' to listOf("01110","10001","10001","11111","10001","10001","10001"),
        'B' to listOf("11110","10001","10001","11110","10001","10001","11110"),
        'C' to listOf("01111","10000","10000","10000","10000","10000","01111"),
        'D' to listOf("11110","10001","10001","10001","10001","10001","11110"),
        'E' to listOf("11111","10000","10000","11110","10000","10000","11111"),
        'F' to listOf("11111","10000","10000","11110","10000","10000","10000"),
        'G' to listOf("01111","10000","10000","10111","10001","10001","01111"),
        'H' to listOf("10001","10001","10001","11111","10001","10001","10001"),
        'I' to listOf("11111","00100","00100","00100","00100","00100","11111"),
        'J' to listOf("00111","00010","00010","00010","10010","10010","01100"),
        'K' to listOf("10001","10010","10100","11000","10100","10010","10001"),
        'L' to listOf("10000","10000","10000","10000","10000","10000","11111"),
        'M' to listOf("10001","11011","10101","10101","10001","10001","10001"),
        'N' to listOf("10001","11001","10101","10011","10001","10001","10001"),
        'O' to listOf("01110","10001","10001","10001","10001","10001","01110"),
        'P' to listOf("11110","10001","10001","11110","10000","10000","10000"),
        'Q' to listOf("01110","10001","10001","10001","10101","10010","01101"),
        'R' to listOf("11110","10001","10001","11110","10100","10010","10001"),
        'S' to listOf("01111","10000","10000","01110","00001","00001","11110"),
        'T' to listOf("11111","00100","00100","00100","00100","00100","00100"),
        'U' to listOf("10001","10001","10001","10001","10001","10001","01110"),
        'V' to listOf("10001","10001","10001","10001","10001","01010","00100"),
        'W' to listOf("10001","10001","10001","10101","10101","10101","01010"),
        'X' to listOf("10001","10001","01010","00100","01010","10001","10001"),
        'Y' to listOf("10001","10001","01010","00100","00100","00100","00100"),
        'Z' to listOf("11111","00001","00010","00100","01000","10000","11111"),
        '0' to listOf("01110","10001","10011","10101","11001","10001","01110"),
        '1' to listOf("00100","01100","00100","00100","00100","00100","01110"),
        '2' to listOf("01110","10001","00001","00010","00100","01000","11111"),
        '3' to listOf("11110","00001","00001","01110","00001","00001","11110"),
        '4' to listOf("00010","00110","01010","10010","11111","00010","00010"),
        '5' to listOf("11111","10000","10000","11110","00001","00001","11110"),
        '6' to listOf("01110","10000","10000","11110","10001","10001","01110"),
        '7' to listOf("11111","00001","00010","00100","01000","01000","01000"),
        '8' to listOf("01110","10001","10001","01110","10001","10001","01110"),
        '9' to listOf("01110","10001","10001","01111","00001","00001","01110"),
        '/' to listOf("00001","00010","00010","00100","01000","01000","10000"),
        '.' to listOf("00000","00000","00000","00000","00000","00100","00100"),
        ':' to listOf("00000","00100","00100","00000","00100","00100","00000"),
        '-' to listOf("00000","00000","00000","11111","00000","00000","00000"),
        '+' to listOf("00000","00100","00100","11111","00100","00100","00000"),
        '%' to listOf("11001","11010","00100","01000","10110","00110","00000")
    )

    fun render(usdUah: String, eurUah: String, usdEur: String, updated: String): Bitmap {
        val bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = BG }
        c.drawRoundRect(RectF(0f, 0f, W.toFloat(), H.toFloat()), 48f, 48f, p)

        // Header
        drawText(c, "EXCHANGE RATES", 54f, 92f, 5.2f, MUTED, 2.2f)
        drawDot(c, 845f, 48f, 7f, RED)
        drawText(c, "NBU UAH", 875f, 92f, 3.8f, MUTED, 1.8f)

        val rows = listOf(
            Triple("USD / UAH", usdUah, 205f),
            Triple("EUR / UAH", eurUah, 345f),
            Triple("USD / EUR", usdEur, 485f)
        )
        rows.forEachIndexed { index, row ->
            drawText(c, row.first, 54f, row.third, 5.0f, WHITE, 2.0f)
            drawTextRight(c, row.second, 945f, row.third + 2f, 6.4f, WHITE, 2.2f)
            // Fine dotted rule, echoing the reference's circular matrix language.
            val y = row.third + 35f
            for (i in 0 until 34) drawDot(c, 55f + i * 10.5f, y, 2.2f, if (i == 33) RED else DIM)
            if (index < 2) {
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF252525.toInt(); strokeWidth = 1f }
                c.drawLine(54f, row.third + 65f, 946f, row.third + 65f, line)
            }
        }

        drawText(c, "LAST UPDATE", 54f, 575f, 3.5f, MUTED, 1.6f)
        drawTextRight(c, updated.uppercase().take(22), 945f, 575f, 3.5f, MUTED, 1.6f)
        return bitmap
    }

    private fun drawTextRight(c: Canvas, text: String, right: Float, baseline: Float, r: Float, color: Int, gap: Float) {
        val step = r * 2f + gap
        val width = text.uppercase().sumOf { (if (it == ' ') 4.0 else 6.0) * step } - gap
        drawText(c, text, right - width, baseline, r, color, gap)
    }


    private fun drawText(c: Canvas, text: String, x: Float, baseline: Float, radius: Float, color: Int, gap: Float) {
        var cursor = x
        val step = radius * 2f + gap
        text.uppercase().forEach { ch ->
            if (ch == ' ') {
                cursor += step * 4f
            } else {
                val pattern = glyphs[ch] ?: glyphs['-']!!
                pattern.forEachIndexed { row, bits ->
                    bits.forEachIndexed { col, bit ->
                        if (bit == '1') drawDot(c, cursor + col * step, baseline - (6 - row) * step, radius, color)
                    }
                }
                cursor += step * 6f
            }
        }
    }

    private fun drawDot(c: Canvas, x: Float, y: Float, radius: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
        c.drawCircle(x, y, radius, paint)
    }
}
