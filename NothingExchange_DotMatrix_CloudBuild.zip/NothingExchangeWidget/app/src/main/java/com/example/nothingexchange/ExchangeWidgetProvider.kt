package com.example.nothingexchange

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class ExchangeWidgetProvider : AppWidgetProvider() {
    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleUpdates(context)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        super.onUpdate(context, manager, ids)
        scheduleUpdates(context)
        WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<ExchangeUpdateWorker>().build())
        ids.forEach { id -> render(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<ExchangeUpdateWorker>().build())
        }
    }

    private fun scheduleUpdates(context: Context) {
        val request = PeriodicWorkRequestBuilder<ExchangeUpdateWorker>(60, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK, ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    companion object {
        const val ACTION_REFRESH = "com.example.nothingexchange.ACTION_REFRESH"
        const val UNIQUE_WORK = "nothing_exchange_hourly"

        fun render(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences(ExchangeUpdateWorker.PREFS, Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, R.layout.widget_exchange)
            val bitmap = DotMatrixRenderer.render(
                prefs.getString("usd_uah", "--.--") ?: "--.--",
                prefs.getString("eur_uah", "--.--") ?: "--.--",
                prefs.getString("usd_eur", "-.----") ?: "-.----",
                prefs.getString("updated", "WAITING FOR DATA") ?: "WAITING FOR DATA"
            )
            views.setImageViewBitmap(R.id.widget_art, bitmap)

            val refreshIntent = Intent(context, ExchangeWidgetProvider::class.java).apply { action = ACTION_REFRESH }
            val pending = PendingIntent.getBroadcast(
                context, 1001, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_art, pending)
            manager.updateAppWidget(widgetId, views)
        }

        fun renderAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ExchangeWidgetProvider::class.java))
            ids.forEach { render(context, manager, it) }
        }
    }
}
