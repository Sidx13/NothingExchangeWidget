plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.nothingexchange"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.nothingexchange"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.work:work-runtime-ktx:2.10.1")
}
